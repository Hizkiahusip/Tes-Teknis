const data = [
    {
        id: 1,
        name: 'Ohrensessel Josslyn',
        price: 499.99,
        currency: 'EUR',
        image: 'images/01.jpg',
      },
      {
        id: 2,
        name: 'Sessel Sofie',
        price: 249.99,
        currency: 'EUR',
        image: 'images/02.jpg',
      }
]

export default data